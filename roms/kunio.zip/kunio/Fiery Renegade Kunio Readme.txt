==========================================================
====================Fiery Renegade Kunio==================
===========================V 1.00=========================
Genre: Action/Brawler

Source language: Japanese

Platform: Famicom

Patch language: English

Author: Pennywise

E-mail: antoniusblocko@protonmail.com
		
http://yojimbo.eludevisibility.org/
 
======================================================
About Fiery Renegade Kunio
======================================================
Project History:

This project officially began last year when I decided
to persue my goal of retranslating all the Nekketsu/Kunio
games. Even though there are various translations offical
or not, I don't feel like the series has been properly
translated consistently across all the games. This game
felt appropriate as the first translation since it's the
first game in the series as well. It was also fairly simple
to do as there was only minimal text. Anyhow, it was through
this project that I found the translator that I can hopefully
work with to translate other games in the series.

======================================================
Patching Instructions
======================================================
Due to limitations in the IPS format, the patch is in
BPS or xdelta format. You can patch it however or go
here:

https://www.romhacking.net/patch/

Apply the patch to the Japanese ROM:

Nekketsu Kouha Kunio-kun (Japan).nes

We would be highly grateful, if you find some time to 
contact us with proposals or corrections. Information
on found bugs or corrections would be highly 
appreciated.

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - hacking

Tana Elmsley - translation

Ryusui - misc translation

Graphicus - graphic design

All those who contributed into this process.

======================================================


Compiled by Pennywise. July 2021